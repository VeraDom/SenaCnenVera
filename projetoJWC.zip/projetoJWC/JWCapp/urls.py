from django.urls import path
from . import views

urlpatterns = [
#     path('',views.home,name='home'),
#     path('produtos/',views.produtos,name='produtos'),
     path('',views.principal,name='default'),
     path('template_trabalhe/',views.template_trabalhe,name='trabalhe_conosco'),
     path('template_contato/',views.template_contato,name='contato_JWC'),
     path('template_candidato/',views.template_candidato,name='area_candidato'),
     path('template_retorno/',views.template_retorno,name='retorno_candidato'),
     path('template_mensagem/',views.template_mensagem,name='mensagem_contato'),     
#     path('template_cadastro/',views.template_cadastro,name='cadastro_candidato'),  
     path('cadastro_candidato/',views.cadastro_candidato,name='cadastro_candidato'),  
     path('listar_candidato/',views.listar_candidatos,name='candidatos')
 ]

