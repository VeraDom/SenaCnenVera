from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home_JWC')
        else:
            return render(request, 'login.html', {'error': 'Credenciais inválidas'})
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

from django.contrib.auth.decorators import login_required
@login_required
def dashboard_view(request):
    return render(request, 'dashboard.html')


from django.http import HttpResponse
from django.template import loader


def principal(request):
    template = loader.get_template('home_JWC.html')
    return HttpResponse(template.render())


def template_trabalhe(request):
    template = loader.get_template('trabalhe_conosco.html')
    return HttpResponse(template.render())

def template_contato(request):
    template = loader.get_template('contato_JWC.html')
    return HttpResponse(template.render())

def template_candidato(request):
    template = loader.get_template('area_candidato.html')
    return HttpResponse(template.render())

def template_retorno(request):
    template = loader.get_template('retorno_candidato.html')
    return HttpResponse(template.render())

def template_mensagem(request):
    template = loader.get_template('mensagem_contato.html')
    return HttpResponse(template.render())

# def template_cadastro(request):
#     template = loader.get_template('cadastro_candidato.html')
#     return HttpResponse(template.render())


from django.shortcuts import render, redirect
from .models import Candidato


def cadastro_candidato(request):
    if request.method == 'POST':
        nome = request.POST['nome']
        CPF = request.POST['CPF']        
        email = request.POST['email']
        msg = request.POST['msg']
        Candidato.objects.create(nome=nome, CPF=CPF, email=email, msg=msg)
        return redirect('candidatos')
    return render(request, 'cadastro_candidato.html')


def listar_candidatos(request):   
    candidatos = Candidato.objects.all()
    return render(request, 'listar_candidato.html', {'candidatos': candidatos})




