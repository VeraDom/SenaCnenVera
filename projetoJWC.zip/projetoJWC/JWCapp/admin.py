from django.contrib import admin

# Register your models here.


from .models import Candidato
# from .models import Pedido
# from .models import Cliente

admin.site.register(Candidato)
# admin.site.register(Pedido)
# admin.site.register(Cliente)
