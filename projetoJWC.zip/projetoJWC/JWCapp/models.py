from django.db import models

# Create your models here.


class Candidato(models.Model):
    id = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=100)
    CPF = models.CharField(max_length=11)
    email = models.CharField(max_length=100)
    msg = models.CharField(max_length=10000)

    def __str__(self):
        return self.nome




# class Cliente(models.Model):
#     id_cliente = models.AutoField(primary_key=True)
#     nome_cliente = models.CharField(max_length=100)
#     email_cliente = models.CharField(max_length=100)
 
#     def __str__(self):
#         return self.nome_cliente


# class Pedido(models.Model):
#     id_pedido = models.AutoField(primary_key=True)
#     id_produto = models.ForeignKey(Produto,to_field='id_produto', on_delete=models.PROTECT)
#     id_cliente = models.ForeignKey(Cliente,to_field='id_cliente',on_delete=models.DO_NOTHING)
#     qtd_pedido = models.IntegerField()


